/**
 * Copyright (c) 2016 - Florin Paraschivescu
 */

(function () {
    // Define option defaults
    var defaults = {
        closeButton: true,
        hideFooter: false,
        className: null,
        width: "auto",
        minWidth: 300,
        position: "bottomLeft",
        backgroundColor: "#000",
        fontSize: 12,
        fontFamily: "Consolas",
        textColor: "#00FF00",
        zIndex: 2147483647
    }

    var options, closeButton, uniqueId = Date.now(), consoleElement;

    this.fConsole = function () {       
		// Create options by extending defaults with the passed in arugments
        if (arguments[0] && typeof arguments[0] === "object") {
            options = extendDefaults(defaults, arguments[0]);
        } else {
            options = defaults;
        }

        //wait to have the document
        var tid = setInterval(function () {
            if (document.readyState !== "complete") return;
            clearInterval(tid);

            fConsole.prototype.init();
        }, 100);
	};
	
	// Public Methods
	fConsole.prototype.init = function() {
		buildHtml.call(this);
		initializeEvents.call(this);
	}

	fConsole.prototype.close = function () {
	    var element = document.getElementById("fConsole-" + uniqueId);
	    element.parentNode.removeChild(element);
	    consoleElement = null;
	}

	fConsole.log = function (obj, interval, bgColor, textColor) {
	    if (!window.jQuery) {
	        console.log("You need jQuery library in order to use this plugin.");
	        return;
	    } else {
	        if (obj != null && obj != "") {
	            if (consoleElement == null) {
	                fConsole.prototype.init();
	            }
	            
	            if (bgColor == null) bgColor = "#000";
	            if (textColor == null) textColor = "#00FF00";
	            
	            var noItemsElement = $("#noItems-" + uniqueId, consoleElement),
                    contentElement = $("#content-" + uniqueId, consoleElement),
                    msgEncoded = $("<div/>").text(obj).html(),
                    uniqueMsgId = "msg-" + Date.now(),
                    msgHtml = "<div id='" + uniqueMsgId + "' style='background-color: " + bgColor + "; color: " + textColor + "; padding: 3px;'>{0}</div>";

	            if ($(noItemsElement).length) {
	                $(noItemsElement).remove();
	            }

	            $(contentElement).append(msgHtml.replace("{0}", msgEncoded));

	            if (typeof obj === "function" && interval != null && isNumeric(interval)) {
	                var timer = setInterval(function () {
	                    $("#" + uniqueMsgId, consoleElement).html(obj);
	                }, interval);
	            }
	        }
	    }
	}

	// Private Methods
	function buildHtml() {
	    var bodyHtml, closeButtonHtml = "", footerHtml = "", consolePosition;

        //close btn
	    if (options.closeButton) {
	        closeButtonHtml = "<div id='head-" + uniqueId + "' style='text-align: right; padding: 5px 5px 0 0;'><a id='closeBtn-" + uniqueId + "' href='javascript:void(0);' style='font-size: 14px; font-family: Consolas; color: #FFF; text-decoration: none;' title='close'>[X]</a></div>";
	    }

        //footer
	    if (!options.hideFooter) {
	        footerHtml = "<div id='footer-" + uniqueId + "' style='position: relative; height: 20px;'><div style='position: absolute; right: 0; bottom: 0; font-style: italic; font-size: 9px; font-family: Consolas; color: #FFF; padding: 2px; color: #4585F2; background-color: #000;'>fConsole v1.0</div></div>";
	    }

	    //position
	    switch (options.position)
	    {
	        case "topLeft": { consolePosition = "top: 0; left: 0;"; break; }
	        case "topRight": { consolePosition = "top: 0; right: 0;"; break; }
	        case "bottomLeft": { consolePosition = "bottom: 0; left: 0;"; break; }
	        case "bottomRight": { consolePosition = "bottom: 0; right: 0;"; break; }
	        default: { consolePosition = "bottomLeft"; break; }
	    }

		if (options.className != null) {
		    bodyHtml = "<div id='fConsole-" + uniqueId + "' class='" + options.className + "'>" + closeButtonHtml + "<div id='content-" + uniqueId + "' style='padding: 10px 10px 5px 10px;'>{0}</div>" + footerHtml + "</div>";
		} else {
		    bodyHtml = "<div id='fConsole-" + uniqueId + "' style='font-family: " + options.fontFamily + "; font-size: " + options.fontSize + "; width: " + options.width + "; " + consolePosition + " position: fixed; background-color: " + options.backgroundColor + "; color: " + options.textColor + "; min-width: " + options.minWidth + "px; z-index: " + options.zIndex + ";'>" + closeButtonHtml + "<div id='content-" + uniqueId + "' style='padding: 10px 10px 5px 10px;'>{0}</div>" + footerHtml + "</div>";
		}
		
		if (!window.jQuery) {
		    var body = document.getElementsByTagName("body")[0];
		    body.innerHTML += bodyHtml.replace("{0}", "<div style='font-family: " + options.fontFamily + ";'>You need jQuery library in order to use this plugin.</div>");

			return;
		}
		
		if (!$("#fConsole-" + uniqueId).length) {
		    $("body").append(bodyHtml.replace("{0}", "<div id='noItems-" + uniqueId + "' style='font-family: " + options.fontFamily + ";'>No items to show in console.</div>"));
		}
		
		consoleElement = $("#fConsole-" + uniqueId);
	}

	function initializeEvents() {
	    if (options.closeButton) {
	        closeButton = document.getElementById("closeBtn-" + uniqueId);
	        closeButton.addEventListener('click', function () {
	            fConsole.prototype.close();
	        });
	    }
	}

	function isNumeric(n) {
	    return !isNaN(parseFloat(n)) && isFinite(n);
	}
	
	// Utility method to extend defaults with user options
	function extendDefaults(source, properties) {
		var property;
		for (property in properties) {
			if (properties.hasOwnProperty(property)) {
				source[property] = properties[property];
			}
		}
		return source;
	}
})();