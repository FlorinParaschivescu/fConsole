var myConsole;

(function () {
    myConsole = new fConsole({
        minWidth: 320
    });

    $(document).ready(function () {
        test1();
        test2();
        test3();
    });

    function test1() {
        $("#test1-action1").on("click", function () {
            fConsole.log("Current URL is: " + $("#test1-elem1").attr("href"));
        });
        $("#test1-action2").on("click", function () {
            fConsole.log("Current TEXT is: " + $("#test1-elem1").text());
        });
        $("#test1-action3").on("click", function () {
            fConsole.log("Current URL is: " + $("#test1-elem1").attr("href"), null, "#FF0000");
        });
        $("#test1-action4").on("click", function () {
            fConsole.log("Current URL is: " + $("#test1-elem1").attr("href"), null, "#0000FF", "#FFF");
        });
    }

    function test2() {
        var height;

        setInterval(function () {
            var top = $("#test2-elem1").css("top").replace("px", "");
            if (top == 0) {
                height = $(".test2-animation-wrapper").height() - $("#test2-elem1").height();
            } else {
                height = 0;
            }
            
            $("#test2-elem1").animate({ "top": height }, 1000);
        }, 1100);

        $("#test2-action1").on("click", function () {
            fConsole.log("Current top position is: " + $("#test2-elem1").css("top"));
        });
    }

    function test3() {
        var height;

        setInterval(function () {
            var top = $("#test3-elem1").css("top").replace("px", "");
            if (top == 0) {
                height = $(".test3-animation-wrapper").height() - $("#test3-elem1").height();
            } else {
                height = 0;
            }

            $("#test3-elem1").animate({ "top": height }, 1000);
        }, 1100);

        $("#test3-action1").on("click", function () {
            fConsole.log(function () { return "Realtime top position is: " + $("#test3-elem1").css("top"); }, 100);
        });
    }
})();